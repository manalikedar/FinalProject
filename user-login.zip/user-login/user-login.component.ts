import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { CapBookService } from '../services/cap-book.service';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  errorMessage:string;
  message:string;
  loginForm = new FormGroup({
    emailId: new FormControl(''),
    password: new FormControl('')
  })
  constructor(private capbookService:CapBookService) { }

  onSubmit():void{
    console.log("In OnSubmit")
   /*  this.capbookService.userLogin(this.loginForm).subscribe(
      message=>{
        this.message=message;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
      ) */
  }
  
  ngOnInit() {
  }

}
